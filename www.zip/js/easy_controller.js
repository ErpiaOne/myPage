/* 더보기 메뉴 / 상품 & 거래처 조회 및 간편등록 컨트롤러 */
angular.module('starter.controllers').controller("EasyCtrl", function($rootScope, $scope) {
console.log("간편 상품 거래처 컨트롤러");
});
